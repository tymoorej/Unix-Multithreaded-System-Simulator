#ifndef INCLUDES_HEADER
#define INCLUDES_HEADER

#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sstream>
#include <sys/time.h>
#include <vector>
#include <fstream>
#include <pthread.h>

using namespace std;

#define NRES_TYPES 10
#define NTASKS 25

#endif